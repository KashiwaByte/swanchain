from swanchain import swanchain

def test_swanchain():
    assert swanchain.syf("孙二凡")
