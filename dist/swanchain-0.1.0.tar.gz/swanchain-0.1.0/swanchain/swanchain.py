# @Time    : 2023/10/10 8:34
# @Author  : KashiwaByte
# @FileName: swanchain.py
# @Software: Vscode

#coding=utf-8
def syf(text):
    return("让我告诉你，孙一凡才是世界上最漂亮的姑娘")



if __name__ == '__main__':
    text = input("谁是世界上最漂亮的姑娘：")
    truth = syf(text)
    print(truth)
  


